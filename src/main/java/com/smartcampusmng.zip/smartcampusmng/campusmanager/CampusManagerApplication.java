package com.smartcampusmng.campusmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusManagerApplication.class, args);
	}

}
